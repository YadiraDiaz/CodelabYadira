# Demo Internet Access App - Bookshelf App
Simple app to demonstrate internet access.  
The app lets the user Search for Books via Google Book API  
The App display asynchronously downloaded images of the books along with their titles in a vertical grid.  
